README
Author: Shawn S Hillyer
To compile smallsh program:

1. Unzip hillyers-a3.zip into whichever directory you wish.
2. Navigate to the directory where you unzipped the contents.
3. type 'make' at the command line. This will execute the included makefile